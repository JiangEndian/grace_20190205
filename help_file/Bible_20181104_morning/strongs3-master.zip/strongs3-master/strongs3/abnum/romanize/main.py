#!/usr/local/bin/python
# -*- coding: utf-8 -*-
# file: main.py

"""
ara, arabic
cop, coptic
eng, english
grc, ancient greek
heb, hebrew
san, sanskrit
"""

from . import ara, cop, eng, grc, heb, san
