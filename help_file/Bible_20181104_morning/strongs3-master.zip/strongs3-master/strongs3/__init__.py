#!/usr/local/bin/python
# -*- coding: utf-8 -*-
# file: __init__.py

from .main import load_dictionary, find, greek, hebrew

load_dictionary()
