# JSONify!

provide tools to turn the Strong's Hebrew XML data into json, and provide a html sample to use as a live dictionay.

> By Sinri Edogawa, 2017 March 18th

> For attribution purposes, the XML building project is https://github.com/openscriptures/HebrewLexicon.

> These files are released under the Creative Commons Attribution 4.0 International(http://creativecommons.org/licenses/by/4.0/) license. The actual text of Brown, Driver, Briggs and Strong’s Hebrew dictionary remain in the public domain.  For attribution purposes, credit the Open Scriptures Hebrew Bible Project. 