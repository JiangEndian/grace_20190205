#start_time为AA制开始时间，可换为start_time_BC/AD制开始时间。
#pass_time为经过的时间段，可换为pass_time_BC/AD制的结束时间
data_dict = {"name":"Adam", "start_time":1, "pass_time":930, "story":'''
Creation, Adma, Eve, Original Sin, Fallen, Judgement, Out of Eden, 
Cain, Abel,
'''}
