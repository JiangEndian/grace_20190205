#start_time为AA制开始时间，可换为start_time_BC/AD制开始时间。
#pass_time为经过的时间段，可换为pass_time_BC/AD制的结束时间
data_dict = {"name":"Xia", "start_time_BC":2070, "pass_time":470, "story":'''
The first Dynasty of China. 
'''}
