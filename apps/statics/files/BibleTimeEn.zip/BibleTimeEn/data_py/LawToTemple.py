#start_time为AA制开始时间，可换为start_time_BC/AD制开始时间。
#pass_time为经过的时间段，可换为pass_time_BC/AD制的结束时间
data_dict = {"name":"LawToTemple", "start_time":2523, "pass_time":480, "story":'''
1 Kings 6-1 In the four hundred and eightieth year after the Israelites came out of Egypt, 
            in the fourth year of Solomon's reign over Israel, 
            in the month of Ziv, the second month, 
            he began to build the temple of the LORD.

This verse became one of two pillars to support this program. Another one is Galatians 3-17.
The age of Solomon was clear, combine this verse to let us determine the year from Adam.
'''}
