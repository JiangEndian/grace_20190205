#start_time为AA制开始时间，可换为start_time_BC/AD制开始时间。
#pass_time为经过的时间段，可换为pass_time_BC/AD制的结束时间
data_dict = {"name":"CovenantToLaw", "start_time":2093, "pass_time":430, "story":'''
Exodus 12-40 Now the length of time the Israelite people lived in Egypt was 430 years.
Galatians 3-17 What I mean is this: The law, introduced 430 years later, 
               does not set aside the covenant 
               previously established by God and thus do away with the promise.

This verse became one of two pillars to support this program. Another one is 1 Kings 6-1.
'''}
