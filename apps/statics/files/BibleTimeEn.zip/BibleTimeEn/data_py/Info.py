#start_time为AA制开始时间，可换为start_time_BC/AD制开始时间。
#pass_time为经过的时间段，可换为pass_time_BC/AD制的结束时间
data_dict = {"name":"Info", "start_time":1, "pass_time":1, "story":'''
This is an application to combine Biblical history and general history.
This is just a framework, you can insert your data to update it.
The purpose of this application is to let us study and understand historical salvation more easily.
The year of AA means After Adam, it's not accurate enough, and cannot be accurate enough.
Many data will be inserted to this application, including biblical history and general history.
A thesis, may a book, will be written to explain and describe this research.
This application will help more ones to study and understand history easily and clearly.
''', "color":'white'}
