#!/bin/bash

./output2html.bash

./simple_output2html.bash

echo 成功

exit 0
